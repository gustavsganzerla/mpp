This is a step by step guide to execute the local version of Multiple Protein Profiler 1.0.

There dependencies for it to execute are
A. Python 3.12
B. The Bio Python package.
C. A command line environment. 

Once points A, B, and C are covered, proceed to:

1. Download the mpp_local.zip file from <url>.
2. Unzip the file.
2. Create a working directory and move mpp.py to the working directory.
3. Ensure you have Python3.12 installed and accessible through command line.
4. Install the Bio package.
	pip3.12 install Bio
5. After installation, you can execute mpp.py.
6. Select the input file containing the proteins you want to predict the physico-chemical structures in .fasta format.
7. Specify the output file, preferably a .csv.


######
ß
The command of mpp.py should look like:

python3.12 mpp.py <input_file.fasta> <output.csv>


